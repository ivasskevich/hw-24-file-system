﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace FileSearchApplication
{
    class Program
    {
        static void Main()
        {
            Console.Write("Enter the directory path (or drive, e.g., C:\\): ");
            string rootPath = Console.ReadLine();

            rootPath = EnsureTrailingSlash(rootPath);
            if (!Directory.Exists(rootPath))
            {
                Console.WriteLine("Invalid path!");
                return;
            }

            Console.Write("Enter the file and directory pattern: ");
            string pattern = Console.ReadLine();
            Regex regex = CreateRegexFromPattern(pattern);

            List<string> results = Search(rootPath, regex);

            if (results.Count == 0)
            {
                Console.WriteLine("No matches found.");
                return;
            }

            DisplayResults(results);

            while (true)
            {
                Console.WriteLine("\nChoose an action:");
                Console.WriteLine("1 - Delete all found items");
                Console.WriteLine("2 - Delete a specific item");
                Console.WriteLine("3 - Delete a range of items");
                Console.WriteLine("0 - Exit");
                Console.Write("Your choice: ");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "0":
                        return;
                    case "1":
                        DeleteAllItems(results);
                        return;
                    case "2":
                        DeleteSingleItem(results);
                        break;
                    case "3":
                        DeleteItemsInRange(results);
                        break;
                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }

                DisplayResults(results);
            }
        }

        static string EnsureTrailingSlash(string path)
        {
            return path.EndsWith("\\") ? path : path + "\\";
        }

        static Regex CreateRegexFromPattern(string pattern)
        {
            string regexPattern = "^" + Regex.Escape(pattern).Replace("\\*", ".*").Replace("\\?", ".") + "$";
            return new Regex(regexPattern, RegexOptions.IgnoreCase);
        }

        static List<string> Search(string path, Regex regex)
        {
            var matches = new List<string>();
            try
            {
                foreach (string file in Directory.GetFiles(path))
                {
                    if (regex.IsMatch(Path.GetFileName(file)))
                    {
                        matches.Add(file);
                    }
                }

                foreach (string dir in Directory.GetDirectories(path))
                {
                    if (regex.IsMatch(Path.GetFileName(dir)))
                    {
                        matches.Add(dir);
                    }

                    matches.AddRange(Search(dir, regex));
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine($"Access denied: {path}");
            }

            return matches;
        }

        static void DisplayResults(List<string> results)
        {
            Console.WriteLine("\nFound files and directories:");
            for (int i = 0; i < results.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {results[i]}");
            }
        }

        static void DeleteAllItems(List<string> items)
        {
            foreach (string item in new List<string>(items))
            {
                DeleteItem(item);
                items.Remove(item);
            }
        }

        static void DeleteSingleItem(List<string> items)
        {
            Console.Write("Enter the item number to delete: ");
            if (int.TryParse(Console.ReadLine(), out int index) && IsValidIndex(index, items))
            {
                string item = items[index - 1];
                DeleteItem(item);
                items.RemoveAt(index - 1);
            }
            else
            {
                Console.WriteLine("Invalid number!");
            }
        }

        static void DeleteItemsInRange(List<string> items)
        {
            Console.Write("Enter the start number: ");
            if (!int.TryParse(Console.ReadLine(), out int start) || !IsValidIndex(start, items))
            {
                Console.WriteLine("Invalid start number!");
                return;
            }

            Console.Write("Enter the end number: ");
            if (!int.TryParse(Console.ReadLine(), out int end) || end < start || !IsValidIndex(end, items))
            {
                Console.WriteLine("Invalid end number!");
                return;
            }

            for (int i = start; i <= end; i++)
            {
                DeleteItem(items[start - 1]);
                items.RemoveAt(start - 1);
            }
        }

        static bool IsValidIndex(int index, List<string> items)
        {
            return index > 0 && index <= items.Count;
        }

        static void DeleteItem(string item)
        {
            try
            {
                if (File.Exists(item))
                {
                    File.Delete(item);
                }
                else if (Directory.Exists(item))
                {
                    Directory.Delete(item, true);
                }

                Console.WriteLine($"Deleted: {item}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to delete {item}: {ex.Message}");
            }
        }
    }
}
