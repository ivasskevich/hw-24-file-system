﻿using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace CSharpApplication.FileSearcher
{
    class Program
    {
        static void Main()
        {
            Console.Write("Enter the folder path: ");
            string directoryPath = Console.ReadLine();

            directoryPath = directoryPath.EndsWith("\\") ? directoryPath : directoryPath + "\\";

            if (!Directory.Exists(directoryPath))
            {
                Console.WriteLine("Invalid path!");
                return;
            }

            Console.Write("Enter the file pattern (* for any number of characters, ? for a single character): ");
            string filePattern = Console.ReadLine();

            Console.Write("Enter the start date (in YYYY-MM-DD format): ");
            if (!DateTime.TryParse(Console.ReadLine(), out DateTime startDate))
            {
                Console.WriteLine("Invalid date format!");
                return;
            }

            Console.Write("Enter the end date (in YYYY-MM-DD format): ");
            if (!DateTime.TryParse(Console.ReadLine(), out DateTime endDate))
            {
                Console.WriteLine("Invalid date format!");
                return;
            }

            Console.Write("Enter the path to save the report: ");
            string reportFilePath = Console.ReadLine();

            try
            {
                using StreamWriter reportWriter = new StreamWriter(reportFilePath, false, Encoding.UTF8);
                ulong totalFilesFound = ProcessDirectory(directoryPath, filePattern, startDate, endDate, reportWriter);
                Console.WriteLine($"Total files found: {totalFilesFound}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error creating the report: {ex.Message}");
            }
        }

        static ulong ProcessDirectory(string path, string filePattern, DateTime startDate, DateTime endDate, StreamWriter reportWriter)
        {
            ulong filesProcessed = 0;

            try
            {
                foreach (string filePath in Directory.GetFiles(path))
                {
                    if (IsFileMatching(filePath, filePattern, startDate, endDate, out string fileDetails))
                    {
                        filesProcessed++;
                        Console.WriteLine(fileDetails);
                        reportWriter.WriteLine(fileDetails);
                    }
                }

                foreach (string subDirectory in Directory.GetDirectories(path))
                {
                    filesProcessed += ProcessDirectory(subDirectory, filePattern, startDate, endDate, reportWriter);
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine($"Access to the folder is denied: {path}");
            }

            return filesProcessed;
        }

        static bool IsFileMatching(string filePath, string filePattern, DateTime startDate, DateTime endDate, out string fileDetails)
        {
            FileInfo fileInfo = new FileInfo(filePath);
            string regexPattern = ConvertPatternToRegex(filePattern);

            if (Regex.IsMatch(fileInfo.Name, regexPattern, RegexOptions.IgnoreCase) &&
                fileInfo.LastWriteTime >= startDate &&
                fileInfo.LastWriteTime <= endDate)
            {
                fileDetails = $"{fileInfo.FullName}, Last modified: {fileInfo.LastWriteTime}";
                return true;
            }

            fileDetails = string.Empty;
            return false;
        }

        static string ConvertPatternToRegex(string pattern)
        {
            return "^" + Regex.Escape(pattern).Replace(@"\*", ".*").Replace(@"\?", ".") + "$";
        }
    }
}
